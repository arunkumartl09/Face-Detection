loaded_Image=load_database();
random_Index=round(50*rand(1,1));

random_Image=loaded_Image(:,random_Index);    
rest_of_the_images=loaded_Image(:,[1:random_Index-1 random_Index+1:end]);

% figure,
%  imshow(uint8(reshape(random_Image,480,640)));

[b,c]=size(loaded_Image);

Re=reshape(random_Image,480,640);

[featureVectorR] = extractHOGFeatures(Re);
%imshow(uint8(Re));

n=1;
 for i=1:1:c
     for j=1:1:b
         m(j,n)=loaded_Image(j,i);
     end
     k=reshape(m,480,640);
     l(i,:)=extractHOGFeatures(k);
     n=1;
 end
 