function output_value = load_database();
persistent loaded;
persistent numeric_Image;
if(isempty(loaded))
     all_Images = zeros(480*640,5);
    for i=1:5
        cd(strcat('s',num2str(i)));
        for j=1:10
            image_Container = imread(strcat(num2str(j),'.jpg.png'));
            gray=rgb2gray(image_Container);
            all_Images(:,(i-1)*10+j)=reshape(gray,size(gray,1)*size(gray,2),1);
          end
       display('Doading Database');
        cd ..
    end
  
    numeric_Image = (all_Images);
  
end
loaded = 1;
output_value = numeric_Image;